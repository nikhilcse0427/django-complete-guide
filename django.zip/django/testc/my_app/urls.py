from django.urls import path,re_path
from . import views

urlpatterns = [
    # path('hello/', views.hello, name='hello'),
    # path('sum/', views.sum, name='sum'),
    path('getval/<int:a>/<int:b>/', views.getval),
    # re_path(r'^regex/(?P<username>[a-zA-Z]+[0-9]*)/$', views.regex),
    re_path(r'^regex/(?P<username>[0-9]{5})/$', views.regex),
    path('a/', views.a, name='a'),
    path('parent/', views.parent, name='parent'),
    path('child/', views.child, name='child'),
    path('incfile', views.include, name='abc'),
    path('valpass/', views.valpass,name='valpass'),

]
