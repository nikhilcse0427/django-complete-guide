from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
# def hello(request):
#     return HttpResponse("Hello, World!")

# def sum(request):
#     a=7
#     b=9
#     return HttpResponse('sum is'+str(a+b))

def getval(request,a,b):
    return HttpResponse(f"The Sum is {a+b}")

def regex(request,username):
    return HttpResponse(f"username={username}")

def a(request):
    return render(request,'my_app/a.html')

def parent(request):
    return render(request,'my_app/parent.html')

def include(request):
    return render(request,'my_app/include.html')
    
def child(request):
    return render(request,'my_app/child.html')
def valpass(request):
    context={'name':'Shobhit',
             'password':'abc',
             'otp':123,
             'mylist':[1,2,3,4,5,6]}
    return render(request,'my_app/child.html',context)
